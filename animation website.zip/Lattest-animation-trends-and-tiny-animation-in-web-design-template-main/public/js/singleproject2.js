



	$(window).load(function() {
		$("#status").fadeOut();
		$("#preloader").delay(50).fadeOut("slow");
	})  







	$(document).ready(
	function() {  
		$("html").niceScroll();
		}
	);	




  $(document).ready(function(){
    $(".media").fitVids();
  });	









