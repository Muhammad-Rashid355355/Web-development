export const working = () => {
    let head = document.getElementsByTagName('head')[0]
    let script = document.createElement('script')
    let script2 = document.createElement('script')
    let script3 = document.createElement('script')
    let script4 = document.createElement('script')
    let script5 = document.createElement('script')
    let script6 = document.createElement('script')
    let script7 = document.createElement('script')
    let script8 = document.createElement('script')
    let script9 = document.createElement('script')
    let script10 = document.createElement('script')
    let script11 = document.createElement('script')
    let script12 = document.createElement('script')
    let script13 = document.createElement('script')
    let script14 = document.createElement('script')
    let script15 = document.createElement('script')
    let script16 = document.createElement('script')
    let script17 = document.createElement('script')
    let script18 = document.createElement('script')
    let script19 = document.createElement('script')
    let script20 = document.createElement('script')
    script.async = 1
    script.src = "js/jquery.js"
    script2.src = "js/modernizr.custom.js"
    script3.src = "js/jquery.nicescroll.min.js"
    script4.src = "js/jquery.lettering.js"
    script5.src = "js/jquery.sticky.js"
    script6.src = "js/jquery.parallax-1.1.3.js"
    script7.src = "js/jquery.localscroll-1.2.7-min.js"
    script8.src = "js/jquery.scrollTo-1.4.2-min.js"
    script9.src = "js/classie.js"
    script10.src = "js/cbpScroller.js"
    script11.src = "js/jquery.knob.js"
    script12.src = "js/jquery.bxslider.min.js"
    script13.src = "js/jquery.easing.min.js"
    script14.src = "js/jquery.typer.html"
    script15.src = "js/jquery.isotope.min.js"
    script16.src = "js/jquery.masonry.min.js"
    script17.src = "js/jquery.colorbox.js"
    script18.src = "js/owl.carousel.min.js"
    script19.src = "js/jquery.mousewheel.js"
    script20.src = "js/template.js"
    head.appendChild(script)
    head.appendChild(script2)
    head.appendChild(script3)
    head.appendChild(script4)
    head.appendChild(script5)
    head.appendChild(script6)
    head.appendChild(script7)
    head.appendChild(script8)
    head.appendChild(script9)
    head.appendChild(script10)
    head.appendChild(script11)
    head.appendChild(script12)
    head.appendChild(script13)
    head.appendChild(script14)
    head.appendChild(script15)
    head.appendChild(script16)
    head.appendChild(script17)
    head.appendChild(script18)
    head.appendChild(script19)
    head.appendChild(script20)
}
